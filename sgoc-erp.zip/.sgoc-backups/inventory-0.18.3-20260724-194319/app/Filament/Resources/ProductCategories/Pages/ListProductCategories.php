<?php
  declare(strict_types=1); namespace App\Filament\Resources\ProductCategories\Pages; use App\Filament\Resources\ProductCategories\ProductCategoryResource; use Filament\Resources\Pages\ListRecords; use Filament\Actions\CreateAction;
  final class ListProductCategories extends ListRecords { protected static string $resource=ProductCategoryResource::class; protected function getHeaderActions(): array { return [CreateAction::make()->label('Novo registro')->icon('heroicon-o-plus')]; } }
